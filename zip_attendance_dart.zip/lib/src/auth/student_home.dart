import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:geolocator/geolocator.dart';
// import 'package:flutter_face_api_beta/face_api.dart' as regula;


class StudentHomePage extends StatefulWidget {
  const StudentHomePage({super.key});

  @override
  State<StudentHomePage> createState() => _StudentHomePageState();
}

class _StudentHomePageState extends State<StudentHomePage> {
  String? _studentName;
  String? _studentEmail;
  String? _studentRoom;
  String? _studentCourse;
  String? _photoBase64;
  List<Map<String, dynamic>> _attendanceRecords = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchStudentData();
  }

  Future<void> _fetchStudentData() async {
    setState(() => _isLoading = true);

    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final doc = await FirebaseFirestore.instance.collection('students').doc(user.uid).get();
      if (doc.exists) {
        final data = doc.data()!;
        setState(() {
          _studentName = data['name'];
          _studentEmail = data['email'];
          _studentRoom = data['roomNo'];
          _studentCourse = data['course'];
          _photoBase64 = data['photoBase64'];
          _attendanceRecords = List<Map<String, dynamic>>.from(data['attendance'] ?? []);
        });
      }
    }

    setState(() => _isLoading = false);
  }

  Future<bool> _isWithinAllowedLocation() async {
    const allowedLatitude = 28.3670;
    const allowedLongitude = 77.3170;
    const allowedRadiusInMeters = 100.0;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        return false;
      }
    }

    final position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);

    final distance = Geolocator.distanceBetween(
      allowedLatitude,
      allowedLongitude,
      position.latitude,
      position.longitude,
    );

    return distance <= allowedRadiusInMeters;
  }

  Future<void> _markAttendance() async {
    try {
      final picked = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 50);
      if (picked == null) return;

      final inputImage = InputImage.fromFilePath(picked.path);

      final options = FaceDetectorOptions(performanceMode: FaceDetectorMode.accurate);
      final faceDetector = FaceDetector(options: options);
      final faces = await faceDetector.processImage(inputImage);

      if (faces.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No face detected. Please try again.')),
        );
        return;
      } else if (faces.length > 1) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Multiple faces detected. Please be alone in the photo.')),
        );
        return;
      }

      final isAllowed = await _isWithinAllowedLocation();
      if (!isAllowed) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('You must be at the university to mark attendance.')),
        );
        return;
      }

      final now = DateTime.now();
      final todayDate = DateTime(now.year, now.month, now.day);

      bool alreadyMarkedToday = _attendanceRecords.any((record) {
        final recordDate = (record['date'] as Timestamp).toDate();
        return recordDate.year == todayDate.year &&
            recordDate.month == todayDate.month &&
            recordDate.day == todayDate.day;
      });

      if (alreadyMarkedToday) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Attendance already marked today')),
        );
        return;
      }

      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final newAttendance = {
        'date': Timestamp.now(),
        'isPresent': true,
      };

      _attendanceRecords.add(newAttendance);

      await FirebaseFirestore.instance.collection('students').doc(user.uid).update({
        'attendance': _attendanceRecords,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Attendance marked successfully')),
      );

      _fetchStudentData();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}')),
      );
    }
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut();
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, '/welcome');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo[700],
      appBar: AppBar(
        title: const Text('Student Home', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.indigo,
        actions: [
          IconButton(
            onPressed: _fetchStudentData,
            icon: const Icon(Icons.refresh, color: Colors.white),
          ),
          IconButton(
            onPressed: _logout,
            icon: const Icon(Icons.logout, color: Colors.white),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (_photoBase64 != null)
              CircleAvatar(
                radius: 55,
                backgroundImage: MemoryImage(base64Decode(_photoBase64!)),
              ),
            const SizedBox(height: 20),
            detailText('Name:', _studentName ?? ''),
            detailText('Email:', _studentEmail ?? ''),
            detailText('Room No:', _studentRoom ?? ''),
            detailText('Course:', _studentCourse ?? ''),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _markAttendance,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.indigo,
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              child: const Text('Mark Attendance'),
            ),
            const SizedBox(height: 30),
            const Text('Attendance Records',
                style: TextStyle(fontSize: 20, color: Colors.white, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._attendanceRecords.map((record) {
              final recordDate = (record['date'] as Timestamp).toDate();
              return ListTile(
                leading: const Icon(Icons.check_circle, color: Colors.white),
                title: Text(
                  '${recordDate.day}/${recordDate.month}/${recordDate.year}',
                  style: const TextStyle(color: Colors.white),
                ),
                subtitle: Text(
                  record['isPresent'] ? 'Present' : 'Absent',
                  style: const TextStyle(color: Colors.white70),
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget detailText(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Text(
        '$title $value',
        style: const TextStyle(fontSize: 18, color: Colors.white),
      ),
    );
  }
}


