import 'package:flutter/material.dart';
import 'student.dart';

class StudentDetailPage extends StatelessWidget {
  final Student student;

  const StudentDetailPage({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo[900],
      appBar: AppBar(
        title: Text(student.name, style: const TextStyle(color: Colors.white)),
        backgroundColor: Colors.indigo[800],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          color: Colors.indigo[700],
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                detailRow('Name', student.name),
                detailRow('Email', student.email),
                detailRow('Room No', student.roomNumber),
                detailRow('Course', student.course),
                const SizedBox(height: 20),
                const Text(
                  'Attendance Records:',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView.builder(
                    itemCount: student.attendanceRecords.length,
                    itemBuilder: (context, index) {
                      final record = student.attendanceRecords[index];
                      return ListTile(
                        title: Text(
                          '${record.date.day}/${record.date.month}/${record.date.year}',
                          style: const TextStyle(color: Colors.white),
                        ),
                        trailing: Icon(
                          record.isPresent ? Icons.check_circle : Icons.cancel,
                          color: record.isPresent ? Colors.greenAccent : Colors.redAccent,
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Text(
        '$label: $value',
        style: const TextStyle(fontSize: 18, color: Colors.white),
      ),
    );
  }
}

