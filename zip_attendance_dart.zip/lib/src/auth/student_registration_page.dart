import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class StudentRegistrationPage extends StatefulWidget {
  const StudentRegistrationPage({super.key});

  @override
  State<StudentRegistrationPage> createState() => _StudentRegistrationPageState();
}

class _StudentRegistrationPageState extends State<StudentRegistrationPage> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _roomController = TextEditingController();
  final _courseController = TextEditingController();
  final _passController = TextEditingController();

  File? _imageFile;
  bool _isUploading = false;

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 50);
    if (picked != null) {
      setState(() {
        _imageFile = File(picked.path);
      });
    }
  }

  Future<void> _registerStudent() async {
    final name = _nameController.text.trim();
    final email = _emailController.text.trim();
    final room = _roomController.text.trim();
    final course = _courseController.text.trim();
    final password = _passController.text.trim();

    if (name.isEmpty || email.isEmpty || room.isEmpty || course.isEmpty || password.isEmpty || _imageFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please fill all fields and upload a photo")));
      return;
    }

    setState(() => _isUploading = true);

    try {
      final bytes = await _imageFile!.readAsBytes();
      final base64Image = base64Encode(bytes);

      final userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final uid = userCredential.user!.uid;

      await FirebaseFirestore.instance.collection('students').doc(uid).set({
        'uid': uid,
        'name': name,
        'email': email,
        'roomNo': room,
        'course': course,
        'photoBase64': base64Image,
        'attendance': [], // ✅ Important: initialize this field
        'createdAt': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Student registered successfully")));
      Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Auth Error: ${e.message}")));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      setState(() => _isUploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo[700],
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('Student Registration',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white)),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: _pickImage,
                child: CircleAvatar(
                  radius: 55,
                  backgroundColor: Colors.white24,
                  backgroundImage: _imageFile != null ? FileImage(_imageFile!) : null,
                  child: _imageFile == null
                      ? const Icon(Icons.camera_alt, color: Colors.white70, size: 35)
                      : null,
                ),
              ),
              const SizedBox(height: 20),
              _buildTextField(controller: _nameController, label: 'Name'),
              _buildTextField(controller: _emailController, label: 'Official Email'),
              _buildTextField(controller: _roomController, label: 'Room No'),
              _buildTextField(controller: _courseController, label: 'Course'),
              _buildTextField(controller: _passController, label: 'Password', obscure: true),
              const SizedBox(height: 30),
              _isUploading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : ElevatedButton(
                onPressed: _registerStudent,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.indigo,
                  padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                ),
                child: const Text('Register'),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    bool obscure = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.white),
          filled: true,
          fillColor: Colors.white24,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}



// import 'dart:io';
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_core/firebase_core.dart';
//
// class StudentRegistrationPage extends StatefulWidget {
//   const StudentRegistrationPage({super.key});
//
//   @override
//   State<StudentRegistrationPage> createState() => _StudentRegistrationPageState();
// }
//
// class _StudentRegistrationPageState extends State<StudentRegistrationPage> {
//   final _nameController = TextEditingController();
//   final _emailController = TextEditingController();
//   final _roomController = TextEditingController();
//   final _courseController = TextEditingController();
//   final _passController = TextEditingController();
//
//   File? _imageFile;
//   bool _isUploading = false;
//
//   Future<void> _pickImage() async {
//     try {
//       final picked = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 50);
//       if (picked != null) {
//         setState(() {
//           _imageFile = File(picked.path);
//         });
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Image pick error: $e")));
//     }
//   }
//
//   Future<void> _registerStudent() async {
//     final email = _emailController.text.trim();
//     final password = _passController.text.trim();
//     final name = _nameController.text.trim();
//     final roomNo = _roomController.text.trim();
//     final course = _courseController.text.trim();
//
//     if (_imageFile == null) {
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please upload a photo")));
//       return;
//     }
//
//     if (email.isEmpty || password.isEmpty || name.isEmpty || roomNo.isEmpty || course.isEmpty) {
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please fill all fields")));
//       return;
//     }
//
//     if (password.length < 6) {
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Password must be at least 6 characters")));
//       return;
//     }
//
//     setState(() => _isUploading = true);
//
//     try {
//       print("Registering user...");
//       final userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
//         email: email,
//         password: password,
//       );
//
//       print("User created: ${userCredential.user!.uid}");
//
//       // Read image and encode
//       final bytes = await _imageFile!.readAsBytes();
//       final base64Image = base64Encode(bytes);
//
//       // Firestore write
//       final userDoc = FirebaseFirestore.instance.collection('students').doc(userCredential.user!.uid);
//
//       await userDoc.set({
//         'uid': userCredential.user!.uid,
//         'name': name,
//         'email': email,
//         'roomNo': roomNo,
//         'course': course,
//         'photoBase64': base64Image,
//         'createdAt': Timestamp.now(),
//       });
//
//       print("Data written to Firestore");
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Student registered successfully")));
//       Navigator.pop(context);
//     } on FirebaseAuthException catch (e) {
//       print("Firebase Auth error: ${e.code} - ${e.message}");
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Auth Error: ${e.message}")));
//     } catch (e) {
//       print("General Error: $e");
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
//     } finally {
//       setState(() => _isUploading = false);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.indigo[700],
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const Text(
//                 'Student Registration',
//                 style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
//               ),
//               const SizedBox(height: 20),
//               GestureDetector(
//                 onTap: _pickImage,
//                 child: CircleAvatar(
//                   radius: 55,
//                   backgroundColor: Colors.white24,
//                   backgroundImage: _imageFile != null ? FileImage(_imageFile!) : null,
//                   child: _imageFile == null
//                       ? const Icon(Icons.camera_alt, color: Colors.white70, size: 35)
//                       : null,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               _buildTextField(controller: _nameController, label: 'Name'),
//               _buildTextField(controller: _emailController, label: 'Official Email'),
//               _buildTextField(controller: _roomController, label: 'Room No'),
//               _buildTextField(controller: _courseController, label: 'Course'),
//               _buildTextField(controller: _passController, label: 'Password', obscure: true),
//               const SizedBox(height: 30),
//               _isUploading
//                   ? const CircularProgressIndicator(color: Colors.white)
//                   : ElevatedButton(
//                 onPressed: _registerStudent,
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.white,
//                   foregroundColor: Colors.indigo,
//                   padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
//                 ),
//                 child: const Text('Register'),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildTextField({required TextEditingController controller, required String label, bool obscure = false}) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 10),
//       child: TextField(
//         controller: controller,
//         obscureText: obscure,
//         style: const TextStyle(color: Colors.white),
//         decoration: InputDecoration(
//           labelText: label,
//           labelStyle: const TextStyle(color: Colors.white),
//           filled: true,
//           fillColor: Colors.white24,
//           border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
//         ),
//       ),
//     );
//   }
// }



// import 'dart:io';
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// class StudentRegistrationPage extends StatefulWidget {
//   const StudentRegistrationPage({super.key});
//
//   @override
//   State<StudentRegistrationPage> createState() => _StudentRegistrationPageState();
// }
//
// class _StudentRegistrationPageState extends State<StudentRegistrationPage> {
//   final _nameController = TextEditingController();
//   final _emailController = TextEditingController(); // Using official email now
//   final _roomController = TextEditingController();
//   final _courseController = TextEditingController();
//   final _passController = TextEditingController();
//
//   File? _imageFile;
//   bool _isUploading = false;
//
//   Future<void> _pickImage() async {
//     final picked = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 50);
//     if (picked != null) {
//       setState(() {
//         _imageFile = File(picked.path);
//       });
//     }
//   }
//
//   Future<void> _registerStudent() async {
//     if (_imageFile == null) {
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please upload a photo")));
//       return;
//     }
//
//     setState(() => _isUploading = true);
//
//     try {
//       final email = _emailController.text.trim();
//       final password = _passController.text.trim();
//       final bytes = await _imageFile!.readAsBytes();
//       final base64Image = base64Encode(bytes);
//
//       final userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
//         email: email,
//         password: password,
//       );
//
//       await FirebaseFirestore.instance.collection('students').doc(userCredential.user!.uid).set({
//         'uid': userCredential.user!.uid,
//         'name': _nameController.text.trim(),
//         'email': email,
//         'roomNo': _roomController.text.trim(),
//         'course': _courseController.text.trim(),
//         'photoBase64': base64Image,
//         'createdAt': Timestamp.now(),
//       });
//
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Student registered successfully")));
//       Navigator.pop(context);
//     } on FirebaseAuthException catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Auth Error: ${e.message}")));
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
//     } finally {
//       setState(() => _isUploading = false);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.indigo[700],
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const Text('Student Registration',
//                   style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white)),
//               const SizedBox(height: 20),
//
//               GestureDetector(
//                 onTap: _pickImage,
//                 child: CircleAvatar(
//                   radius: 55,
//                   backgroundColor: Colors.white24,
//                   backgroundImage: _imageFile != null ? FileImage(_imageFile!) : null,
//                   child: _imageFile == null
//                       ? const Icon(Icons.camera_alt, color: Colors.white70, size: 35)
//                       : null,
//                 ),
//               ),
//
//               const SizedBox(height: 20),
//               _buildTextField(controller: _nameController, label: 'Name'),
//               _buildTextField(controller: _emailController, label: 'Official Email'),
//               _buildTextField(controller: _roomController, label: 'Room No'),
//               _buildTextField(controller: _courseController, label: 'Course'),
//               _buildTextField(controller: _passController, label: 'Password', obscure: true),
//
//               const SizedBox(height: 30),
//               _isUploading
//                   ? const CircularProgressIndicator(color: Colors.white)
//                   : ElevatedButton(
//                 onPressed: _registerStudent,
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.white,
//                   foregroundColor: Colors.indigo,
//                   padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
//                 ),
//                 child: const Text('Register'),
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildTextField({required TextEditingController controller, required String label, bool obscure = false}) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 10),
//       child: TextField(
//         controller: controller,
//         obscureText: obscure,
//         style: const TextStyle(color: Colors.white),
//         decoration: InputDecoration(
//           labelText: label,
//           labelStyle: const TextStyle(color: Colors.white),
//           filled: true,
//           fillColor: Colors.white24,
//           border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
//         ),
//       ),
//     );
//   }
// }


